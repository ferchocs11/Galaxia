// ----- CONFIGURACIÓN PRINCIPAL -----
const frases = [
    "Eres mi estrella favorita",
    "Te quiero más de lo que imaginas",
    "Mi universo eres tú",
    "Contigo todo brilla",
    "Tu luz es mi guía",
    "Eres mi galaxia entera",
    "Mi amor por ti es infinito"
];

// ----- ESCENA -----
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 2000);
camera.position.z = 5;

const renderer = new THREE.WebGLRenderer({ canvas: document.getElementById("galaxy") });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(window.devicePixelRatio);

// ----- ESTRELLAS -----
const starGeometry = new THREE.BufferGeometry();
const starCount = 2000;
const starPositions = new Float32Array(starCount * 3);

for (let i = 0; i < starCount * 3; i++) {
    starPositions[i] = (Math.random() - 0.5) * 200;
}

starGeometry.setAttribute("position", new THREE.BufferAttribute(starPositions, 3));

const starMaterial = new THREE.PointsMaterial({
    color: 0xffffff,
    size: 0.7
});

const stars = new THREE.Points(starGeometry, starMaterial);
scene.add(stars);

// ----- TEXTO DE FRASES -----
const loader = new THREE.FontLoader();
let textos = [];

loader.load("https://threejs.org/examples/fonts/helvetiker_regular.typeface.json", font => {
    frases.forEach((f, i) => {
        const textGeometry = new THREE.TextGeometry(f, {
            font: font,
            size: 1,
            height: 0.1
        });

        const textMaterial = new THREE.MeshBasicMaterial({ color: 0xff66ff });
        const textMesh = new THREE.Mesh(textGeometry, textMaterial);

        textMesh.position.set(
            (Math.random() - 0.5) * 50,
            (Math.random() - 0.5) * 50,
            (Math.random() - 0.5) * 50
        );

        textos.push(textMesh);
        scene.add(textMesh);
    });
});

// ----- ANIMACIÓN -----
function animate() {
    requestAnimationFrame(animate);

    stars.rotation.y += 0.0008;
    stars.rotation.x += 0.0003;

    textos.forEach(t => {
        t.lookAt(camera.position);
    });

    renderer.render(scene, camera);
}

animate();

// ----- AJUSTAR PANTALLA -----
window.addEventListener("resize", () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
});